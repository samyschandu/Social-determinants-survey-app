package uicinnovation.board;

import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.BackgroundSize;

public class gridNode extends Button {
    Point2D coordinate;
    boolean cardPresent;
    Card card;

    public gridNode(double x, double y, Boolean cardPresent){
        coordinate = new Point2D(x,y);
        this.cardPresent = cardPresent;
        setMinSize(100, 55); // 86,45
        setMaxSize(BackgroundSize.DEFAULT.getWidth(),45);
        setStyle("-fx-background-color: rgba(0, 0, 0, 0.35);");
    }

}
