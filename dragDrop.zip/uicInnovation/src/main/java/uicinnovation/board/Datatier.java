package uicinnovation.board;

import javafx.geometry.Point2D;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Datatier {


    public Datatier() throws SQLException {
    }

    Connection con = DatabaseConnection.getInstance().getConnection();


//    public synchronized int addAll(int id, String title, int zipCode, Point2D coordinate, String color) throws SQLException {
//
//        String query = "Insert GridData (ZipCode, CardID, XCoor, YCoor, TokenColor) VALUES (?, ?, ?, ?, ?, ?)";
//        PreparedStatement ps = con.prepareStatement(query);
//        ps.setInt(1, id);
//        ps.setInt(2, zipCode);
//        ps.setString(3, title);
//        ps.setDouble(4, coordinate.getX());
//        ps.setDouble(5, coordinate.getY());
//        ps.setString(6, color);
//
//        return ps.executeUpdate();
//    }

    // TODO: Change token color parameter to hashmap.
    public synchronized int addAll(int zipcode, HashMap<String, Point2D> finalGrid, String color) throws SQLException {

        String query = "Insert PersonData (ZipCode, C1_XCoor, C1_YCoor, C1_Token," +
                "C2_XCoor, C2_YCoor, C2_Token," +
                "C3_XCoor, C3_YCoor, C3_Token," +
                "C4_XCoor, C4_YCoor, C4_Token," +
                "C5_XCoor, C5_YCoor, C5_Token," +
                "C6_XCoor, C6_YCoor, C6_Token," +
                "C7_XCoor, C7_YCoor, C7_Token," +
                "C8_XCoor, C8_YCoor, C8_Token," +
                "C9_XCoor, C9_YCoor, C9_Token," +
                "C10_XCoor, C10_YCoor, C10_Token," +
                "C11_XCoor, C11_YCoor, C11_Token," +
                "C12_XCoor, C12_YCoor, C12_Token)" +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, zipcode);
        List<Integer> params = new ArrayList<>();
        finalGrid.forEach((k,v) -> {
            int i = getCardID(k);
            if (i != -1) {
                try {
                    ps.setDouble(i, v.getX());
                    ps.setDouble(i + 1, v.getY());
                    ps.setString(i + 2, color);
                    params.add(i);
                    params.add(i+1);
                    params.add(i+2);
                } catch (SQLException e) {
                    System.out.println("Couldn't insert into table");
                    e.printStackTrace();
                }
            }
//            else {
//                try {
//                    ps.setNull(old.getAndIncrement(), Types.DOUBLE);
//                    ps.setNull(old.getAndIncrement(), Types.DOUBLE);
//                    ps.setNull(old.getAndIncrement(), Types.LONGNVARCHAR);
//                } catch (SQLException e) {
//                    System.out.println("Couldn't insert into table");
//                    e.printStackTrace();
//                }
//            }
        });


        for (int i = 2; i<38; i++) {
            if (!params.contains(i)){
                try {
                    if (i % 3 == 1)
                        ps.setNull(i, Types.LONGNVARCHAR);
                    else
                        ps.setNull(i, Types.DOUBLE);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }



        return ps.executeUpdate();
    }


    public int getCardID(String str) {
        return switch (str) {
            case "employment" -> 2;
            case "money" -> 5;
            case "home" -> 8;
            case "food" -> 11;
            case "transportation" -> 14;
            case "mentalHealth" -> 17;
            case "healthcare" -> 20;
            case "legal" -> 23;
            case "education" -> 26;
            case "protection" -> 29;
            case "timeManagement" -> 32;
            case "family" -> 35;
            default -> -1;
        };
    }


    // TODO: ADD OTHER FUNCTIONS!

//
//    public synchronized int updateCoor(int id, String title, Point2D coordinate) throws SQLException {
//        String query = "Update PersonData set XCoor = ? and YCoor = ? where id = ? and title = ?";
//        PreparedStatement ps = con.prepareStatement(query);
//        ps.setDouble(1, coordinate.getX());
//        ps.setDouble(2, coordinate.getY());
//        ps.setInt(3, id);
//        ps.setString(4, title);
//        return ps.executeUpdate();
//    }


//    public synchronized List<String> getAllData() throws SQLException {
//        String query = "select * from GridData";
//        PreparedStatement ps = con.prepareStatement(query);
//        ResultSet rs = ps.executeQuery();
//        List<String> result = new LinkedList<>();
//
//        while(rs.next()) {
//            String id = String.valueOf(rs.getInt("id"));
//            String title = rs.getString("title");
//            String zip = String.valueOf(rs.getInt("zipcode"));
//            String coor = rs.getDouble("xcoor") + " " + rs.getDouble("ycoor");
//            String str = id + " -> " + zip + " zip: " + title + " " + coor;
//            result.add(str);
//        }
//
//        return result;
//    }

//    public synchronized int getLastId() throws SQLException {
//        int id = -1;
//        String query = "select max(ID) from GridData";
//        PreparedStatement ps = con.prepareStatement(query);
//        ResultSet rs = ps.executeQuery();
//        if(rs.next())
//            id = rs.getInt(1);
//        return id;
//    }



}



