package uicinnovation.board;

import javafx.geometry.Point2D;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Card extends Rectangle {
    Point2D coordinates;
    String color;
    String title;      // unique id
    Image image;
//    int id;

    public Card(){
        coordinates = new Point2D(-1,-1);
        color = null;
        title = null;
        image = null;
    }

    public Card(String title, String image){
        coordinates = new Point2D(-1,-1);
        color = null;
        this.title = title;
        this.image = new Image(image);
//        this.id = id;
//        setFill(new ImagePattern(image,0,0,10,10,false));
//        setStyle("-fx-background-image: url(resources/" + image + ")");
    }
}
