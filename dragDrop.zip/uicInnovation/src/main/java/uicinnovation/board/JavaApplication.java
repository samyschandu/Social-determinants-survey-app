package uicinnovation.board;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.HashMap;


public class JavaApplication extends Application {


    Stage primaryStage;  // for changing scenes
    int id = 0;

    ArrayDeque<Card> cardsArray = new ArrayDeque<>();

    HashMap<String, Token> tokens = new HashMap<>(); // title, token
    HashMap<String, Point2D> finalPosition = new HashMap<>(); // title, coordinates

    HashMap<Point2D, gridNode> board = new HashMap<>();
    Card selectedCard;
    gridNode old;
    boolean successInDrag = false;
    boolean dragWithinGrid = false;
    boolean submitWindowOpen = false;
    TextArea descripText = new TextArea("Description");

    HashMap<String, String> imageNames = new HashMap<>(); // title, image name
    HashMap<String, String> descriptions = new HashMap<>();     // title, descrip

    Datatier collectData;

    Button leftButton;
    Button rightButton;
    Button submitYes;
    BorderPane root = new BorderPane();
    GridPane grid  = new GridPane();
    VBox cardBox = new VBox();



    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;
        stage.setTitle("Card Sort Board");
        addImagesNames();
        stage.setScene(createBoard());
        stage.show();
    }




    public void addImagesNames(){
        // todo: add more images and cards. -> switch case with image number?

        imageNames.put("mentalHealth", "CardsBW_Individual5.jpg");
        descriptions.put("mentalHealth", "Mental Health Description");

        imageNames.put("money", "CardsBW_Individual6.jpg");
        descriptions.put("money", "Money is any item or verifiable record that is " +
                "generally accepted as payment for goods and services and repayment " +
                "of debts, such as taxes.");

        imageNames.put("employment", "CardsBW_Individual11.jpg");
        descriptions.put("employment", "Employment is an agreement between an individual " +
                "and another entity that stipulates the responsibilities.");

        imageNames.put("transportation", "CardsBW_Individual9.jpg");
        descriptions.put("transportation", "Transportation Description");


    }


    EventHandler<MouseEvent> GridNodeDragDetected = mouseEvent -> {
            gridNode node = (gridNode) mouseEvent.getSource();
            System.out.println();
            System.out.println("GRID NODE drag detected");
            if (!node.cardPresent) {
                System.out.println("NODE CARD NOT PRESENT");
                return;
            }
            Dragboard db = node.startDragAndDrop(TransferMode.ANY);
            selectedCard = node.card;
            ClipboardContent cbContent = new ClipboardContent();
            cbContent.putImage(selectedCard.image);

            db.setContent(cbContent);
            node.setVisible(false);

            successInDrag = false;
            mouseEvent.consume();
    };


    EventHandler<DragEvent> GridNodeDragDone = dragEvent -> {
        gridNode node = (gridNode) dragEvent.getSource();
        if (dragEvent.getTransferMode() == TransferMode.MOVE) {
            System.out.println("GRID NODE drag DONE " + node.card.title + " " + node.card.coordinates);
            node.setVisible(false);
            node.cardPresent = false;
        }
        dragEvent.consume();
    };


    public void createGrid() {
        grid.setMinHeight(450);
        grid.setAlignment(Pos.BOTTOM_CENTER);

        grid.setMaxHeight(BackgroundSize.AUTO);
        grid.setMaxWidth(BackgroundSize.AUTO);
        grid.setMinWidth(1000);
        //grid.setStyle("-fx-background-color: rgba(81, 81, 81, 0.43);");
        for (int r = 0; r < 10; r++){
            for (int c = 0; c < 10; c++){
                gridNode node = new gridNode(r,c,false);
                node.setGraphic(null);
//                node.setText();
                grid.add(node, c, r);
                board.put(new Point2D(r,c), node);

                node.setOnDragDetected(GridNodeDragDetected);
                node.setOnDragDone(GridNodeDragDone);

//                node.setDisable(true);
//                node.setOnDragOver(dragEvent -> {
//                    if (dragEvent.getGestureSource() != node &&
//                            dragEvent.getDragboard().hasString()) {
//                        /* allow for both copying and moving, whatever user chooses */
//                        dragEvent.acceptTransferModes(TransferMode.COPY_OR_MOVE);
//                    }
//                    dragEvent.consume();
//                });
            }
        }

        grid.setOnDragOver(event -> {
            if (event.getGestureSource() != grid && event.getDragboard().hasImage()) {
                event.acceptTransferModes(TransferMode.MOVE);
            }
            event.consume();
        });

        //Drag entered changes the appearance of the grid -> changing opacity
        grid.setOnDragEntered(event -> {
            if (event.getGestureSource() != grid && event.getDragboard().hasImage()) {
                cardBox.setVisible(false);
                grid.setOpacity(0.7);
                System.out.println("grid Drag entered : " + selectedCard.title);
            }
            event.consume();
        });

        grid.setOnDragExited(event -> {
            cardBox.setVisible(true);
//             TODO: fix -> if card already present for grid node
//            if(!successInDrag && dragWithinGrid) {
//
//            }
            grid.setOpacity(1);
            System.out.println("grid drag exited : " + selectedCard.title);
            event.consume();
        });

        grid.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();

//                int x, y;
            successInDrag = false;
            if (db.hasImage()) {
                // get the destination
                Node source = (Node) event.getTarget();
                Integer colIndex = GridPane.getColumnIndex(source);
                Integer rowIndex = GridPane.getRowIndex(source);
                if(rowIndex == null || colIndex == null)
                    return;
                System.out.printf("Mouse entered cell [%d, %d]%n", rowIndex, colIndex);
                gridNode node = board.get(new Point2D(rowIndex, colIndex));

                // TODO: fix -> if card already present when changing in the grid.
                if(node.cardPresent){
                    System.out.println("CARD ALREADY PRESENT IN THIS NODE");
                    return;
                }

                // : Update coordinates for card
                // : only update when it is the card. ?? check with title

                if(!cardsArray.isEmpty() && cardsArray.getFirst().title.equals(selectedCard.title)) {
                    cardsArray.getFirst().coordinates = new Point2D(rowIndex, colIndex);
                } else {

                    Point2D oldPos = finalPosition.get(selectedCard.title);
                    old = new gridNode(oldPos.getX(), oldPos.getY(),false);
                    old.setOnDragDetected(GridNodeDragDetected);
                    old.setOnDragDone(GridNodeDragDone);
//                        old.setStyle(null);

//                        old.setGraphic(null);

//                        old.card = null;
                    grid.add(old,(int) oldPos.getY(), (int) oldPos.getX());
                    board.put(new Point2D((int) oldPos.getX(), (int) oldPos.getY()), old);
//                        node = old;
//                        System.out.println("SHOULD BE OLD NODE " + node.coordinate);
                    dragWithinGrid = true;
                }

                node.card = selectedCard;
                node.coordinate = new Point2D(rowIndex, colIndex);
                node.cardPresent = true;

                ImageView img = new ImageView(selectedCard.image);
                img.setFitHeight(node.getHeight());
                img.setFitWidth(node.getWidth());

                node.setGraphic(img);

//                    System.out.println("node card : " + node.card.title + " " + node.cardPresent);




                selectedCard.coordinates = new Point2D(rowIndex, colIndex);
//                    cardsArray.getFirst().coordinates = node.coordinate;
                if(!cardsArray.isEmpty())
                    System.out.println("cards array : " + cardsArray.getFirst().title + "  " + cardsArray.getFirst().coordinates.toString());
                else
                    System.out.println("cards array empty");

                System.out.println("selected card: " + selectedCard.title + "  " + selectedCard.coordinates.toString());


//                    node.setBackground(new Background(
//                                    new BackgroundImage(selectedCard.image,
//                                            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
//                                            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, false)
//                                    )
//                            )
//                    );

//                    grid.get
//                    grid.add(selectedCard, 0, 0, 1, 1);
                successInDrag = true;

                if(!dragWithinGrid)
                    cardsArray.removeFirst();   // removes card from the array as placed to the grid.
            }
            event.setDropCompleted(successInDrag);
            System.out.println("card dropped into the grid");
            finalPosition.put(selectedCard.title, selectedCard.coordinates);
            event.consume();
        });



    }

    public void createCards(){
        for(String t : imageNames.keySet()){
            Card c = new Card(t, imageNames.get(t));
            cardsArray.add(c);
//            cardBox.setBackground(new Background());
//            c.addEventHandler(MouseEvent.MOUSE_ENTERED, event -> c.setCursor(Cursor.HAND));

//            c.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
//                c.setCursor(Cursor.MOVE);
//
//                //When a press event occurs, the location coordinates of the event are cached
////                pos.x = event.getX();
////                pos.y = event.getY();
//            });

//            c.setOnMousePressed(mouseEvent -> {
//                Dragboard db = c.startDragAndDrop(TransferMode.ANY);
//                ClipboardContent content = new ClipboardContent();
//                content.putString(c.title);
//                db.setContent(content);
//                mouseEvent.consume();
//            });

        }
//        cardBox.getChildren().addAll(cardsArray);
    }


    // todo : token
    public void chooseToken(){
        // only if node.cardPresent is true -> then only token option

    }

    //
    // When user clicks submitButton, if yes-> stores into database and
    // goes to final screen. if no -> takes back to the grid.
    // Function creates a pop-up window and adds functionality
    //
    EventHandler<ActionEvent> pressSubmitButton = new EventHandler<>() {
        @Override
        public void handle(ActionEvent actionEvent) {
            if (submitWindowOpen)
                return;
            Text text = new Text("Are you sure you want to submit your response?");
            // create a popup scene
            Stage popstage = new Stage();

            Button submitNo = new Button("No");
            submitYes = new Button("Yes");
            submitNo.setMinSize(60, 50);
            submitYes.setMinSize(60, 50);
            submitNo.setFont(Font.font("Arial", 20));
            submitYes.setFont(Font.font("Arial", 20));
            submitNo.setFocusTraversable(false);
            submitYes.setFocusTraversable(false);


            submitNo.setOnAction(e -> {
                submitWindowOpen = false;
                popstage.close();
            });


            // TODO: submit yes -> send data and move to end screen
            submitYes.setOnAction(e -> {
                submitWindowOpen = false;
                try {
                    collectData = new Datatier();
                    // TODO: if hashmap is empty -> show error message


                    // todo: insert into table.
                    // todo: token color set to "null" -> to change according to selected.
                    // todo: zipcode set to 60607 -> would be where the application is located.

                    // if same as the size of hashmap -> increment id?
//                    int id = collectData.getLastId() + 1;
//                    Thread thread = new Thread( () -> finalPosition.forEach((k, v) -> {
////                        System.out.println(k + " -> " + v.getX() + ", " + v.getY());
//                        try {
////                            int n = collectData.addAll(k, 60607, v, "noColor");
////                            System.out.println(n);
//                        } catch (SQLException ex) {
//                            System.out.println("ERROR WITH INSERTING INTO THE TABLE");
//                            ex.printStackTrace();
//                        }
//                    })
//                    );


                    Thread thread = new Thread( () -> {
                        try {
                            int n = collectData.addAll(60607, finalPosition, "noColor");
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
//                        int n = collectData.addAll()
                    });

                    thread.start();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

                // goes to final end screen
                popstage.close();
                primaryStage.setScene(createEndScreen());
            });


            HBox options = new HBox(submitYes, submitNo);
            options.setAlignment(Pos.CENTER);
            options.setSpacing(35);

            VBox box = new VBox(text, options);
            box.setSpacing(40);
            text.setDisable(true);
            text.setFill(Color.BLACK);

            text.setStyle("-fx-fill: rgba(168, 137, 235, 0.7);");
            text.setFont(Font.font("Arial", 20));
            // set the background
            box.setStyle("-fx-background-color: black;");
            box.setAlignment(Pos.CENTER);

            Scene sc = new Scene(box, 800, 500);
            popstage.setScene(sc);
            popstage.setOpacity(0.87);
            popstage.show();
            submitWindowOpen = true;  // scene is now open
            popstage.setOnCloseRequest(e -> {
                submitWindowOpen = false;
            });
        }
    };



    public Scene createBoard(){

        root.setBackground(new Background(new BackgroundFill(Color.CORAL, CornerRadii.EMPTY, Insets.EMPTY)));

        leftButton = new Button("<");
        leftButton.setFocusTraversable(false);
        leftButton.setOnAction(actionEvent -> {
            if (!cardsArray.isEmpty()) {
//                System.out.println("came into the right button event");
                // get the top card and then add it to the back
                Card last = cardsArray.removeLast();
                cardsArray.addFirst(last);
                cardBox.setBackground(new Background(
                                new BackgroundImage(new Image(imageNames.get(cardsArray.getFirst().title)),
                                        BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, false)
                                )
                        )
                );
                descripText.setText(descriptions.get(cardsArray.getFirst().title));
            } else {
                // todo: set it back to false if cards gets added back to the queue
                leftButton.setDisable(true);
                rightButton.setDisable(true);
            }
        });


        rightButton = new Button(">");
        rightButton.setFocusTraversable(false);
        rightButton.setOnAction(actionEvent -> {
            if (!cardsArray.isEmpty()) {
//                System.out.println("came into the right button event");
                // get the top card and then add it to the back
                Card top = cardsArray.removeFirst();
                cardsArray.addLast(top);
                selectedCard = cardsArray.getFirst();
                cardBox.setBackground(new Background(
                                new BackgroundImage(new Image(imageNames.get(cardsArray.getFirst().title)),
                                        BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, false)
                                )
                        )
                );
                descripText.setText(descriptions.get(cardsArray.getFirst().title));
            } else {
                // todo: set it back to false if cards gets added back to the queue
                leftButton.setDisable(true);
                rightButton.setDisable(true);
            }
        });


        createGrid();

        cardBox.setBackground(new Background(new BackgroundFill(Color.CORAL, CornerRadii.EMPTY, Insets.EMPTY)));
        cardBox.setMinSize(250, 250);
        createCards();

        selectedCard = cardsArray.getFirst();
        cardBox.getChildren().add(cardsArray.getFirst());

        // added first card
        cardBox.setBackground(new Background(
                                new BackgroundImage(new Image(imageNames.get(cardsArray.getFirst().title)),
                                    BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                                    new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, false)
                                )
                                )
        );
        cardBox.addEventHandler(MouseEvent.MOUSE_ENTERED, event -> cardBox.setCursor(Cursor.HAND));


        cardBox.setOnDragDetected(event -> {
            System.out.println();
            dragWithinGrid = false;
            Dragboard db = cardBox.startDragAndDrop(TransferMode.ANY);
            selectedCard = cardsArray.getFirst();
            ClipboardContent cbContent = new ClipboardContent();
            cbContent.putImage(selectedCard.image);

            db.setContent(cbContent);
            cardBox.setVisible(false);

            System.out.println("drag detected on the cardBox : " + selectedCard.title);
            successInDrag = false;
            event.consume();
        });


        cardBox.setOnDragDone(event -> {
            if (event.getTransferMode() == TransferMode.MOVE) {
                dragWithinGrid = false;
                System.out.println("card-box drag done handler entered");
                if (!cardsArray.isEmpty()) {
                    cardBox.setBackground(new Background(
                                    new BackgroundImage(new Image(imageNames.get(cardsArray.getFirst().title)),
                                            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                                            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, false)
                                    )
                            )
                    );
                    descripText.setText(descriptions.get(cardsArray.getFirst().title));
                    cardBox.setVisible(true);
                    selectedCard = cardsArray.getFirst();
//                        cardsArray.removeFirst();
                } else {
                    cardBox.setBackground(new Background(
                                    new BackgroundImage(new Image("temp_done.png"),
                                            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                                            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                                    )
                            )
                    );
                    descripText.setText("User have gone through all cards and can submit when ready.");
                    cardBox.setVisible(true);
                    cardBox.setDisable(true);
                    // set right button and left button to disable as array is empty.
                    rightButton.setDisable(true);
                    leftButton.setDisable(true);
                }
            }
            if (!successInDrag) {
                System.out.println("coming here");
                cardBox.setVisible(true);
            }
            event.consume();
        });


//        cardBox.setAlignment(Pos.CENTER_RIGHT);


        descripText.setDisable(true);
        descripText.setOpacity(0.7);
        descripText.setMaxSize(300,100);
        descripText.setWrapText(true);
        descripText.setText(descriptions.get(cardsArray.getFirst().title));


        Button submitButton = new Button("SUBMIT");
        submitButton.setFocusTraversable(false);
        submitButton.setMinSize(60,50);
        submitButton.setFont(Font.font("Times New Roman", FontWeight.EXTRA_BOLD, 13));
        submitButton.setOnAction(pressSubmitButton);


        HBox header = new HBox(leftButton, cardBox, rightButton, descripText, submitButton);
        header.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        header.setMinSize(250, 250);
        header.setPadding(new Insets(10,10,10,10));
        header.setSpacing(25);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setMargin(descripText, new Insets(25,25,25,25));
        root.setTop(header);

        // TODO: Put all the cards
        HBox gradient = new HBox();
        gradient.setBackground(
                new Background(
                        new BackgroundImage(new Image("/CardSort_Gameboard.png"),
                            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                        )
                )
        );
        gradient.getChildren().add(grid);
//        grid.setBackground(new Background());
        grid.setGridLinesVisible(true);
//        gradient.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));

//        gradient.setMinSize(850, 650);
//        gradient.setMaxSize(850, 650);
//        gradient.setMaxSize(250, 250);
        gradient.setAlignment(Pos.CENTER);
        root.setCenter(gradient);

        Scene board = new Scene(root, 1000, 850);
        return board;
    }



    public Scene createEndScreen() {
        Text txt = new Text("THANK YOU!");
        txt.setFont(Font.font("Times New Roman",  FontWeight.BLACK, 40));

        Button newClientButton = new Button("NEW CLIENT");
        newClientButton.setFont(Font.font("Times New Roman",  FontWeight.MEDIUM, 20));
        newClientButton.setMinSize(150, 80);
        newClientButton.setMaxSize(150, 80);
        newClientButton.setFocusTraversable(false);

        Button exitButton = new Button("EXIT");
        exitButton.setMinSize(150, 80);
        exitButton.setMaxSize(150, 80);
        exitButton.setFont(Font.font("Times New Roman",  FontWeight.MEDIUM, 20));
        exitButton.setFocusTraversable(false);
        exitButton.setOnAction(e-> {
            Platform.exit(); System.exit(0); });

        // TODO: New client button
        // Clear board, grid, hashmap
        // add all cards back to the array dequeue
        // database -> create a new id -> get row number from the table?


        HBox box1 = new HBox(newClientButton, exitButton);
        box1.setAlignment(Pos.BOTTOM_CENTER);
        box1.setSpacing(50);

        VBox box = new VBox(txt, box1);
        box.setSpacing(70);
        box.setStyle("-fx-background-color: gray;");
        box.setAlignment(Pos.CENTER);

        return new Scene(box, 1000, 850);
    }



}
