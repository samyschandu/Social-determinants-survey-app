package uicinnovation.board;

import javafx.scene.control.Button;

public class Token {
    String title;
    String color;
}
