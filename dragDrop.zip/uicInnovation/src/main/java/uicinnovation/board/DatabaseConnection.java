package uicinnovation.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class DatabaseConnection {

    private static DatabaseConnection dbConInstance;
    private Connection con = null;

    private String url = "jdbc:mysql://localhost:3306/GridDB";
    private String user = "root";
    private String pass = "uicInnovation";

//    boolean noDB = false;

    private DatabaseConnection() {
        try{
            Class.forName("uicinnovation.board.JavaApplication");
            con = DriverManager.getConnection(url, user, pass);
//            PreparedStatement ps = conn.prepareStatement("CREATE DATABASE IF NOT EXISTS GRID_DATA");
//            ps.execute();
        }
        catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }


    public synchronized Connection getConnection() {
        return con;
    }

    public synchronized static DatabaseConnection getInstance() throws SQLException {
//        synchronized (DatabaseConnection.class) {
            if (dbConInstance == null)
                dbConInstance = new DatabaseConnection();
            else if (dbConInstance.getConnection().isClosed())
                dbConInstance = new DatabaseConnection();

            return dbConInstance;
//        }
    }

}
