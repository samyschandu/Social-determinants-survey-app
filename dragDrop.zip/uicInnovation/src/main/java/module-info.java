module uicinnovation.board {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires javafx.graphics;
    requires java.sql;

//    opens com.example.uicinnovation to javafx.fxml;
    exports uicinnovation.board;
}